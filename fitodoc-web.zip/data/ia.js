// Instrucciones, esquema de respuesta y llamada a Google Gemini (plan gratuito).
// Se usa igual desde el navegador (clave guardada en el dispositivo) y desde server.js.
(function (root) {
  const KB = root.KB || (typeof require !== "undefined" ? require("./kb.js") : null);

  const catalogo = KB.PLAGAS.map(
    (p) => `- ${p.id}: ${p.nombre} (${p.cientifico}; ${p.tipo}; cultivos: ${p.cultivos.join(", ")})`
  ).join("\n");

  const SYSTEM = `Eres un agrónomo y fitopatólogo experto en diagnóstico de plagas, enfermedades y desórdenes de cultivos y plantas de todo tipo (hortalizas, granos, frutales, café, cacao, ornamentales, plantas de interior, césped).

Recibirás una foto de la planta, una descripción de síntomas, o ambas. Identifica el problema más probable y hasta 2 alternativas. Responde siempre en español, con lenguaje sencillo para agricultores.

Reglas:
- Si la imagen no muestra una planta o no se puede diagnosticar, pon es_planta=false o confianza "baja" y explica en siguiente_paso qué foto tomar (hoja por ambos lados, tallo, fruto, planta completa, a buena luz).
- Considera también causas no infecciosas (nutrición, riego, sol, fertilizante, herbicida).
- Si el problema coincide con una entrada del catálogo, pon su id en kb_id; si no, deja kb_id vacío y da el tratamiento tú mismo.
- En tratamiento químico menciona ingredientes activos genéricos, nunca marcas, y recuerda revisar el registro local y la etiqueta.
- Prioriza manejo integrado: cultural y biológico primero, químico como último recurso.
- Si es una plaga de reporte obligatorio (p. ej. Foc R4T, HLB, moko), dilo en "alerta"; si no, deja "alerta" vacío.

Catálogo interno de la app:
${catalogo}`;

  const S = (d) => ({ type: "string", description: d });
  const LISTA = { type: "array", items: { type: "string" } };
  const SCHEMA = {
    type: "object",
    required: ["es_planta", "cultivo_detectado", "que_observe", "diagnosticos", "siguiente_paso", "alerta"],
    properties: {
      es_planta: { type: "boolean" },
      cultivo_detectado: S("Cultivo o planta reconocido"),
      que_observe: S("Síntomas que se ven en la foto o se entienden de la descripción"),
      diagnosticos: {
        type: "array",
        items: {
          type: "object",
          required: ["nombre", "cientifico", "tipo", "confianza", "kb_id", "por_que", "cultural", "biologico", "quimico", "prevencion"],
          properties: {
            nombre: S("Nombre común"),
            cientifico: S("Nombre científico"),
            tipo: S("Hongo, Bacteria, Virus, Insecto, Ácaro, Nematodo, Abiótico..."),
            confianza: { type: "string", enum: ["alta", "media", "baja"] },
            kb_id: S("id del catálogo o vacío"),
            por_que: S("Por qué se llega a este diagnóstico"),
            cultural: LISTA, biologico: LISTA, quimico: LISTA,
            prevencion: S("Cómo evitar que vuelva"),
          },
        },
      },
      siguiente_paso: S("Qué hacer ahora o qué foto adicional tomar"),
      alerta: S("Alerta sanitaria o vacío"),
    },
  };

  const MODELO_GEMINI = "gemini-flash-latest";
  const API = "https://generativelanguage.googleapis.com/v1beta";

  function userText(cultivo, descripcion) {
    return `Cultivo o planta indicado por el usuario: ${cultivo || "no indicado"}\nSíntomas descritos: ${descripcion || "ninguno"}\n\nDiagnostica el problema.`;
  }

  function parseDataUrl(image) {
    const m = /^data:(image\/(?:jpeg|png|webp|gif|heic|heif));base64,(.+)$/.exec(image || "");
    if (!m) throw Object.assign(new Error("Formato de imagen no soportado"), { status: 400 });
    return { mime: m[1], data: m[2] };
  }

  async function llamarGemini({ image, cultivo, descripcion }, apiKey, modelo, fetchFn) {
    const f = fetchFn || fetch;
    const parts = [];
    if (image) { const { mime, data } = parseDataUrl(image); parts.push({ inline_data: { mime_type: mime, data } }); }
    parts.push({ text: userText(cultivo, descripcion) });
    const body = {
      system_instruction: { parts: [{ text: SYSTEM }] },
      contents: [{ role: "user", parts }],
      generationConfig: { temperature: 0.2, responseMimeType: "application/json", responseSchema: SCHEMA },
    };
    const r = await f(`${API}/models/${modelo || MODELO_GEMINI}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify(body),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      const razon = data?.error?.details?.find((d) => d.reason)?.reason || data?.error?.status;
      let msg = "Error del servicio de IA gratuito (Gemini).";
      if (razon === "API_KEY_INVALID") msg = "La clave de Gemini no es válida. Revísala.";
      else if (r.status === 429) msg = "Se alcanzó el límite gratuito de consultas por ahora. Espera un minuto (o hasta mañana si es el límite diario).";
      else if (r.status === 404) msg = `El modelo "${modelo || MODELO_GEMINI}" no está disponible para esta clave.`;
      throw Object.assign(new Error(msg), { status: r.status === 429 ? 429 : 502, detalle: data?.error?.message });
    }
    const cand = data.candidates?.[0];
    const text = (cand?.content?.parts || []).map((p) => p.text || "").join("");
    if (!text) throw Object.assign(new Error("La IA no devolvió un diagnóstico (bloqueado: " + (cand?.finishReason || data.promptFeedback?.blockReason || "desconocido") + ")."), { status: 422 });
    return JSON.parse(text);
  }

  const IA = { SYSTEM, SCHEMA, MODELO_GEMINI, userText, parseDataUrl, llamarGemini };
  if (typeof module !== "undefined" && module.exports) module.exports = IA;
  else root.IA = IA;
})(typeof window !== "undefined" ? window : globalThis);
